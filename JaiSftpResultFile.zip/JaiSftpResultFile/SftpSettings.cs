﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace JaiSftpResultFile
{
    public class SftpSettings
    {
        public string Host { get; set; }
        public int Port { get; set; } = 22;
        public string Username { get; set; }
        public string Password { get; set; }
        public string RemotePath { get; set; }
        public string LocalDownloadPath { get; set; }
        public string FilePattern { get; set; } = "*.*";
        public bool DeleteAfterDownload { get; set; } = false;
    }
}
