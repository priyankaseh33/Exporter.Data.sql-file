﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Threading.Tasks;
using Renci.SshNet;
using Renci.SshNet.Sftp;

namespace JaiSftpResultFile
{
    public class SftpService
    {
        private readonly SftpSettings _settings;
        private readonly string _connectionString;
        private readonly string _logPath;
        private readonly string _iisPath;

        public SftpService(SftpSettings settings, string connectionString, string logPath, string iisPath)
        {
            _settings = settings;
            _connectionString = connectionString;
            _logPath = logPath;
            _iisPath = iisPath;
        }

        public async Task RunAsync(Guid batchId)
        {
            int filesFound = 0, filesDownloaded = 0, filesFailed = 0, filesSkipped = 0;
            DateTime pollStart = DateTime.Now;
            int logId = InsertPollLog(batchId, pollStart);

            try
            {
                using (var sftp = new SftpClient(_settings.Host, _settings.Port, _settings.Username, _settings.Password))
                {
                    sftp.ConnectionInfo.Timeout = TimeSpan.FromSeconds(30);
                    sftp.Connect();
                    Log("INFO", $"[Job {batchId}] Connected to {_settings.Host}:{_settings.Port}");

                    IEnumerable<ISftpFile> remoteFiles = sftp.ListDirectory(_settings.RemotePath);

                    foreach (var file in remoteFiles)
                    {
                        if (file.IsDirectory || file.Name.StartsWith(".")) continue;
                        if (!MatchesPattern(file.Name, _settings.FilePattern)) continue;

                        filesFound++;

                        // Skip if already downloaded
                        if (FileAlreadyDownloaded(file.Name, file.LastWriteTime))
                        {
                            Log("INFO", $"[Job {batchId}] Skipped (already exists): {file.Name}");
                            filesSkipped++;
                            continue;
                        }

                        string localPath = Path.Combine(_settings.LocalDownloadPath, file.Name);

                        try
                        {
                            // ── Download file bytes from SFTP ───────
                            byte[] fileBytes;
                            using (var ms = new MemoryStream())
                            {
                                await Task.Run(() => sftp.DownloadFile(file.FullName, ms));
                                fileBytes = ms.ToArray();
                            }

                            // ── Save to local backup folder ─────────
                            await File.WriteAllBytesAsync(localPath, fileBytes);
                            Log("INFO", $"[Job {batchId}] Downloaded: {file.Name} ({fileBytes.Length} bytes)");

                            // ── Copy to IIS web folder ──────────────
                            try
                            {
                                Directory.CreateDirectory(_iisPath);
                                string iisFilePath = Path.Combine(_iisPath, file.Name);
                                await File.WriteAllBytesAsync(iisFilePath, fileBytes);
                                Log("INFO", $"[Job {batchId}] Copied to IIS: {file.Name}");
                            }
                            catch (Exception iisEx)
                            {
                                Log("WARN", $"[Job {batchId}] IIS copy failed: {file.Name} — {iisEx.Message}");
                            }

                            // ── Insert to SQL ───────────────────────
                            string base64 = Convert.ToBase64String(fileBytes);
                            string contentType = GetContentType(file.Name);
                            InsertFileRecord(batchId, file, localPath, base64, contentType, null);

                            if (_settings.DeleteAfterDownload)
                                sftp.DeleteFile(file.FullName);

                            filesDownloaded++;
                        }
                        catch (Exception ex)
                        {
                            filesFailed++;
                            Log("ERROR", $"[Job {batchId}] Failed: {file.Name} — {ex.Message}");
                            InsertFileRecord(batchId, file, null, null, null, ex.Message);
                        }
                    }

                    sftp.Disconnect();
                }

                UpdatePollLog(logId, DateTime.Now, filesFound, filesDownloaded, filesFailed, "Completed", null);
                Log("INFO", $"[Job {batchId}] Done. Found={filesFound} Downloaded={filesDownloaded} Skipped={filesSkipped} Failed={filesFailed}");
            }
            catch (Exception ex)
            {
                UpdatePollLog(logId, DateTime.Now, filesFound, filesDownloaded, filesFailed, "Failed", ex.Message);
                Log("ERROR", $"[Job {batchId}] Job failed: {ex.Message}");
            }
        }

        // ── SQL Helpers ────────────────────────────────────────────
        private void InsertFileRecord(Guid batchId, ISftpFile file, string localPath,
            string base64, string contentType, string error)
        {
            string status = error == null ? "Downloaded" : "Failed";
            string ext = Path.GetExtension(file.Name).TrimStart('.').ToLower();

            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string sql = @"
                    INSERT INTO [dbo].[RESULT_SftpFiles]
                        (FileName, RemotePath, LocalPath, FileSize, FileExtension,
                         ContentType, FileContent, LastModified, DownloadedAt,
                         Status, ErrorMessage, BatchId)
                    VALUES
                        (@FileName, @RemotePath, @LocalPath, @FileSize, @FileExtension,
                         @ContentType, @FileContent, @LastModified, GETDATE(),
                         @Status, @ErrorMessage, @BatchId)";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@FileName", file.Name);
                    cmd.Parameters.AddWithValue("@RemotePath", file.FullName);
                    cmd.Parameters.AddWithValue("@LocalPath", (object)localPath ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@FileSize", file.Length);
                    cmd.Parameters.AddWithValue("@FileExtension", ext);
                    cmd.Parameters.AddWithValue("@ContentType", (object)contentType ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@FileContent", (object)base64 ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@LastModified", file.LastWriteTime);
                    cmd.Parameters.AddWithValue("@Status", status);
                    cmd.Parameters.AddWithValue("@ErrorMessage", (object)error ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@BatchId", batchId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private int InsertPollLog(Guid batchId, DateTime start)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string sql = @"
                    INSERT INTO [dbo].[RESULT_SftpPollLog] (BatchId, PollStartTime, Status)
                    VALUES (@BatchId, @Start, 'Running');
                    SELECT SCOPE_IDENTITY();";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@BatchId", batchId);
                    cmd.Parameters.AddWithValue("@Start", start);
                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        private void UpdatePollLog(int logId, DateTime end, int found, int downloaded, int failed, string status, string error)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string sql = @"
                    UPDATE [dbo].[RESULT_SftpPollLog]
                    SET PollEndTime=@End, FilesFound=@Found, FilesDownloaded=@Downloaded,
                        FilesFailed=@Failed, Status=@Status, ErrorMessage=@Error
                    WHERE LogId=@LogId";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@End", end);
                    cmd.Parameters.AddWithValue("@Found", found);
                    cmd.Parameters.AddWithValue("@Downloaded", downloaded);
                    cmd.Parameters.AddWithValue("@Failed", failed);
                    cmd.Parameters.AddWithValue("@Status", status);
                    cmd.Parameters.AddWithValue("@Error", (object)error ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@LogId", logId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // ── FIX: Only skip when BOTH DB record exists AND local file is physically present ──
        private bool FileAlreadyDownloaded(string fileName, DateTime lastModified)
        {
            string localPath = Path.Combine(_settings.LocalDownloadPath, fileName);

            bool existsInDb = false;
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string sql = @"
                    SELECT COUNT(1)
                    FROM   [dbo].[RESULT_SftpFiles]
                    WHERE  FileName     = @FileName
                    AND    LastModified = @LastModified
                    AND    Status       = 'Downloaded'";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@FileName", fileName);
                    cmd.Parameters.AddWithValue("@LastModified", lastModified);
                    existsInDb = (int)cmd.ExecuteScalar() > 0;
                }
            }

            return existsInDb && File.Exists(localPath);
        }

        // ── Utilities ──────────────────────────────────────────────
        private bool MatchesPattern(string fileName, string pattern)
        {
            if (pattern == "*.*" || pattern == "*") return true;
            return fileName.EndsWith(pattern.TrimStart('*'), StringComparison.OrdinalIgnoreCase);
        }

        private string GetContentType(string fileName) =>
            Path.GetExtension(fileName).ToLower() switch
            {
                ".pdf" => "application/pdf",
                ".xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                ".xls" => "application/vnd.ms-excel",
                ".csv" => "text/csv",
                ".txt" => "text/plain",
                ".zip" => "application/zip",
                ".xml" => "application/xml",
                ".json" => "application/json",
                ".jpg" => "image/jpeg",
                ".png" => "image/png",
                _ => "application/octet-stream"
            };

        public void Log(string level, string message)
        {
            string line = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [{level}] {message}";
            Console.WriteLine(line);
            try
            {
                Directory.CreateDirectory(_logPath);
                string logFile = Path.Combine(_logPath, $"JaiSftpResultFile_{DateTime.Now:yyyyMMdd}.log");
                File.AppendAllText(logFile, line + Environment.NewLine);
            }
            catch { }
        }
    }
}