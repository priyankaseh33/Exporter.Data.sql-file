﻿using System.Collections.Generic;

namespace JaiSftpResultFile
{
    public class AppSettings
    {
        public string SftpHost { get; set; }
        public int SftpPort { get; set; }
        public string SftpUsername { get; set; }
        public string SftpPassword { get; set; }
        public string SftpRemotePath { get; set; }
        public string SftpFilePattern { get; set; }
        public bool SftpDeleteAfterDownload { get; set; }
        public string LocalBackupDirectory { get; set; }
        public string LogDirectory { get; set; }
        public List<TimeSpan> ScheduleTimes { get; set; }
        public string IISSftpFilesPath { get; set; }  
    }

}
