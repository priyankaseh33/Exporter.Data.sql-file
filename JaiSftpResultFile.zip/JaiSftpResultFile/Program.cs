﻿using System;
using System.IO;
using System.Threading.Tasks;
using System.Configuration;

namespace JaiSftpResultFile
{
    class Program
    {
        static async Task Main(string[] args)
        {
            try
            {
                string connectionString = ConfigurationManager
                    .ConnectionStrings["DefaultConnection"].ConnectionString;

                Console.WriteLine("[JaiSftpResultFile] Connecting to database...");
                AppSettings appSettings = SettingsLoader.Load(connectionString);
                Console.WriteLine("[JaiSftpResultFile] Settings loaded OK.");

                var sftpSettings = new SftpSettings
                {
                    Host = appSettings.SftpHost,
                    Port = appSettings.SftpPort,
                    Username = appSettings.SftpUsername,
                    Password = appSettings.SftpPassword,
                    RemotePath = appSettings.SftpRemotePath,
                    LocalDownloadPath = appSettings.LocalBackupDirectory,
                    FilePattern = appSettings.SftpFilePattern,
                    DeleteAfterDownload = appSettings.SftpDeleteAfterDownload
                };

                Directory.CreateDirectory(sftpSettings.LocalDownloadPath);
                Directory.CreateDirectory(appSettings.LogDirectory);

                var service = new SftpService(sftpSettings, connectionString, appSettings.LogDirectory,    appSettings.IISSftpFilesPath);
                service.Log("INFO", $"Host={sftpSettings.Host} | RemotePath={sftpSettings.RemotePath}");

                // ── Run once and exit ──────────────────────────────
                await service.RunAsync(Guid.NewGuid());

                service.Log("INFO", "Job completed. Exiting.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[FATAL] {ex.Message}");
                Console.WriteLine(ex.StackTrace);
            }
        }
    }
}
