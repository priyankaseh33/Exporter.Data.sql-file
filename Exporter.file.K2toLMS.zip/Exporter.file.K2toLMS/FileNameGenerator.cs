﻿using System;
using System.IO;
using System.Text.RegularExpressions;

namespace Exporter.file.K2toLMS
{
    public class FileNameGeneratorV2
    {
        // Folder that will be scanned to calculate {N} (ideally BACKUP_FOLDER)
        private readonly string scanFolder;

        public FileNameGeneratorV2(string scanFolder)
        {
            this.scanFolder = scanFolder;
        }

        /// <summary>
        /// Generate file name from template, filling date and count number if needed.
        /// Template example: LMS_SALEREPO_CRL_STATUS_SALE_CAR_{N}_{AD_YYYYMMDD}
        /// </summary>
        public string GenerateFileName(string fileNameTemplate, DateTime date)
        {
            string datePart = date.ToString("yyyyMMdd");

            bool needsCount = fileNameTemplate.Contains("{N}");
            int count = needsCount ? GetNextCount(fileNameTemplate, datePart) : 0;

            string fileName = fileNameTemplate
                .Replace("{AD_YYYYMMDD}", datePart)
                .Replace("{N}", needsCount ? count.ToString() : string.Empty);

            return fileName;
        }

        /// <summary>
        /// Scan scanFolder for files matching template and find max count N for that date.
        /// </summary>
        private int GetNextCount(string fileNameTemplate, string datePart)
        {
            // Build regex directly, replacing tokens with regex parts.
            // Example template: LMS_SALEREPO_CRL_STATUS_SALE_CAR_{N}_{AD_YYYYMMDD}
            string regexPattern = fileNameTemplate
                .Replace("{N}", "(\\d+)")
                .Replace("{AD_YYYYMMDD}", datePart);

            // If your template never contains regex meta characters, this is safe.
            var regex = new Regex("^" + regexPattern + "$");

            int maxN = 0;

            if (!Directory.Exists(scanFolder))
                return 1;

            var files = Directory.GetFiles(scanFolder);
            foreach (var filePath in files)
            {
                var fileName = Path.GetFileNameWithoutExtension(filePath); // ignore .txt
                var match = regex.Match(fileName);
                if (match.Success &&
                    match.Groups.Count > 1 &&
                    int.TryParse(match.Groups[1].Value, out int n) &&
                    n > maxN)
                {
                    maxN = n;
                }
            }

            return maxN + 1;
        }


    }
}
