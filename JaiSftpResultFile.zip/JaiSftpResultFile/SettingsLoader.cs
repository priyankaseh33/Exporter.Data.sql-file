﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace JaiSftpResultFile
{
    public static class SettingsLoader
    {
        public static AppSettings Load(string connectionString)
        {
            var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand("usp_GetDownloadSettings", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string name = reader["setting_name"].ToString().Trim();
                            string value = reader["setting_value"]?.ToString().Trim();
                            dict[name] = value;
                        }
                    }
                }
            }

            return new AppSettings
            {
                SftpHost = GetRequired(dict, "SFTP_Host"),
                SftpPort = int.Parse(GetRequired(dict, "SFTP_Port")),
                SftpUsername = GetRequired(dict, "SFTP_Username"),
                SftpPassword = GetRequired(dict, "SFTP_Password"),
                SftpRemotePath = GetOrDefault(dict, "SFTP_Remote_Path", "/"),
                SftpFilePattern = GetOrDefault(dict, "SFTP_File_Pattern", "*.*"),
                SftpDeleteAfterDownload = bool.Parse(GetOrDefault(dict, "SFTP_Delete_After_Download", "false")),
                LocalBackupDirectory = GetRequired(dict, "Local_Backup_Directory"),
                LogDirectory = GetOrDefault(dict, "Log_Directory", "C:\\Logs"),
                ScheduleTimes = ParseTimes(GetOrDefault(dict, "Schedule_Hours", "10:00,16:30,18:30,19:30,20:30,21:30")),
                IISSftpFilesPath = GetOrDefault(dict, "IIS_SftpFiles_Path", "C:\\inetpub\\wwwroot\\K2\\SftpFiles")  
            };
        }

        private static string GetRequired(Dictionary<string, string> dict, string key)
        {
            if (!dict.TryGetValue(key, out string val) || string.IsNullOrEmpty(val))
                throw new Exception($"Required setting '{key}' is missing in RESULT_download_settings table.");
            return val;
        }

        private static string GetOrDefault(Dictionary<string, string> dict, string key, string defaultValue)
            => dict.TryGetValue(key, out string val) && !string.IsNullOrEmpty(val) ? val : defaultValue;

        private static List<TimeSpan> ParseTimes(string csv)
        {
            var times = new List<TimeSpan>();
            foreach (var part in csv.Split(','))
                if (TimeSpan.TryParse(part.Trim(), out TimeSpan t))
                    times.Add(t);
            return times;
        }
    }
}
